"""SQLAlchemy engine / session for NeurON chat."""

from __future__ import annotations

from collections.abc import Generator

from sqlalchemy import create_engine, text
from sqlalchemy.orm import DeclarativeBase, Session, sessionmaker

from app.config import get_config


class Base(DeclarativeBase):
    pass


def _make_engine():
    cfg = get_config()
    url = str(cfg["database_url"])
    connect_args = {"check_same_thread": False} if url.startswith("sqlite") else {}
    return create_engine(url, connect_args=connect_args, future=True)


engine = _make_engine()
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False, future=True)


def _migrate_sqlite() -> None:
    cfg = get_config()
    if not str(cfg["database_url"]).startswith("sqlite"):
        return
    with engine.begin() as conn:
        cols = {row[1] for row in conn.execute(text("PRAGMA table_info(chat_sessions)")).fetchall()}
        if cols and "telegram_topic_id" not in cols:
            conn.execute(text("ALTER TABLE chat_sessions ADD COLUMN telegram_topic_id INTEGER"))


def init_db() -> None:
    from app import models  # noqa: F401

    Base.metadata.create_all(bind=engine)
    _migrate_sqlite()


def get_db() -> Generator[Session, None, None]:
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
