"""Entry re-export for hosting panels that look for server/main.py.

ASGI app object: ``app`` (FastAPI).
Under cPanel Passenger use ``passenger_wsgi.py`` (WSGI via a2wsgi), not this file.
"""

from app.main import app

__all__ = ["app"]
